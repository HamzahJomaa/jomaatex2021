exports.Index = (req,res,next)=>{
    res.render("front/index")
}