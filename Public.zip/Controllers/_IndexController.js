exports.Index = (req,res,next)=>{
    res.render("admin/index")
}
